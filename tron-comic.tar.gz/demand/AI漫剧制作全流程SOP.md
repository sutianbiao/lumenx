# 云创 AI 漫剧制作全流程 SOP

> [!NOTE]
> 本文档是 云创 AI 漫剧/短剧视频制作的标准操作流程（SOP），涵盖从剧本到成片的完整工作流。
> 适用于 comic_gen 项目的开发和使用。

## 📋 目录

1. [工作流概览](#工作流概览)
2. [前期准备：剧本分析与素材提取](#前期准备剧本分析与素材提取)
3. [素材生成阶段](#素材生成阶段)
4. [分镜图生成](#分镜图生成)
5. [分镜视频生成](#分镜视频生成)
6. [音频制作](#音频制作)
7. [后期优化与导出](#后期优化与导出)
8. [技术栈与模型配置](#技术栈与模型配置)
9. [最佳实践与常见问题](#最佳实践与常见问题)

---

## 工作流概览

![AI漫剧制作流程图](/Users/hoshinoren/.gemini/antigravity/brain/6540afd0-69ff-4884-ac5e-18304ca0202a/uploaded_image_1764230472891.png)

### 核心制作流程

```mermaid
graph TD
    A[原始剧本] --> B[剧本分析与提取]
    B --> C[分镜脚本生成]
    B --> D[角色/场景/道具提取]
    
    D --> E[角色三视图生成]
    D --> F[场景图生成]
    D --> G[道具图生成]
    
    C --> H[分镜图生成]
    E --> H
    F --> H
    G --> H
    
    H --> I[分镜优化]
    I --> J[图生视频]
    
    J --> K[角色配音]
    J --> L[环境音效]
    
    K --> M[音视频合成]
    L --> M
    
    M --> N[后期优化]
    N --> O[成片导出]
```

### 阶段时间估算

| 阶段 | 预估时长 | 关键输出 |
|------|----------|----------|
| 剧本分析与提取 | 10-20分钟 | 结构化分镜脚本、角色列表 |
| 素材生成 | 30-60分钟 | 角色三视图、场景图、道具图 |
| 分镜图生成 | 40-90分钟 | 完整分镜序列 |
| 分镜视频生成 | 60-120分钟 | 视频片段 |
| 音频制作 | 20-40分钟 | 配音、音效 |
| 后期合成导出 | 15-30分钟 | 最终成片 |

---

## 前期准备：剧本分析与素材提取

### 步骤 1.1：剧本结构化分析

**目标**：将自然语言剧本转换为结构化的分镜脚本数据

**使用模型**：
- 推荐：Qwen3-Plus (API)
- 可选：Qwen3-30B-A3B (独立部署)

**操作步骤**：

1. **准备剧本文件**
   - 支持格式：`.txt`, `.docx`, `.pdf`
   - 确保剧本包含场景描述、对话、动作指示

2. **执行分镜脚本拆分**

```python
from src.apps.comic_gen.llm import extract_storyboard_script

# 读取剧本
with open("script.txt", "r", encoding="utf-8") as f:
    raw_script = f.read()

# 调用 LLM 进行结构化提取
structured_script = extract_storyboard_script(
    raw_script=raw_script,
    model="qwen-plus",
    split_strategy="scene"  # 按场景拆分
)
```

3. **输出示例**

```json
{
  "scenes": [
    {
      "scene_id": "S001",
      "location": "室内客厅 - 夜晚",
      "characters": ["男主角", "女主角"],
      "props": ["茶几", "蜂蜜水", "白色沙发"],
      "shots": [
        {
          "shot_id": "S001_01",
          "shot_type": "全景",
          "camera_angle": "平视",
          "duration": 3,
          "action": "男生背靠沙发，女生俯身贴近",
          "dialogue": "女生：你真的决定了吗？",
          "emotion": "女生：担忧，男生：犹豫"
        }
      ]
    }
  ]
}
```

**提示词模板**：

```
你是一位专业的影视分镜师。请将以下剧本拆分为详细的分镜脚本。

要求：
1. 提取每个场景的核心信息：地点、时间、天气、光线
2. 识别所有出场角色及其情绪状态
3. 提取场景中的重要道具和布景元素
4. 将场景拆分为独立的镜头（shot），每个镜头包含：
   - 镜头类型（全景/中景/特写/远景等）
   - 机位角度（平视/俯视/仰视/斜角等）
   - 镜头时长（秒）
   - 角色动作描述
   - 对话内容
   - 情绪状态

请以 JSON 格式输出，结构如下：
{
  "scenes": [...]
}

原始剧本：
{raw_script}
```

---

### 步骤 1.2：角色/场景/道具元素提取

**目标**：从分镜脚本中提取需要生成的视觉元素清单

**操作步骤**：

1. **角色提取**

```python
from src.apps.comic_gen.llm import extract_characters

characters = extract_characters(structured_script)

# 输出示例
[
  {
    "name": "男主角",
    "description": "25岁左右，黑色短发，身材修长，穿着白色衬衫和黑色长裤",
    "personality": "冷静、理性、内敛",
    "appearances": ["S001", "S002", "S005"]  # 出现的场景
  },
  {
    "name": "女主角",
    "description": "23岁左右，长发及肩，身着粉色连衣裙",
    "personality": "温柔、善良、坚强",
    "appearances": ["S001", "S003", "S005"]
  }
]
```

2. **场景提取**

```python
scenes = extract_scenes(structured_script)

# 输出示例
[
  {
    "scene_id": "LOC_001",
    "name": "室内客厅",
    "description": "现代风格客厅，窗外夜景，白色沙发，玻璃茶几",
    "time": "夜晚",
    "weather": "晴",
    "lighting": "室内暖光 + 窗外城市灯光"
  }
]
```

3. **道具提取**

```python
props = extract_props(structured_script)

# 输出示例
[
  {
    "prop_id": "PROP_001",
    "name": "蜂蜜水杯",
    "description": "透明玻璃杯，内装半杯蜂蜜水，放置在茶几上",
    "scenes": ["S001"]
  }
]
```

**提示词示例**（角色提取）：

```
从以下分镜脚本中提取所有角色信息：

要求：
1. 识别所有角色名称
2. 根据剧本描述，总结角色的外貌特征（年龄、发型、身材、服装）
3. 总结角色的性格特点
4. 列出角色出现的场景编号

请以 JSON 数组格式输出。

分镜脚本：
{structured_script}
```

---

## 素材生成阶段

### 步骤 2.1：角色三视图生成

**目标**：生成角色的正视图、侧视图、背视图，确保后续分镜中角色一致性

**使用模型**：
- 文生图：Midjourney (API) / Wanx2.5-t2i / Qwen-Image
- 图像编辑：Wan2.5-i2i / Qwen-Image-edit

**操作步骤**：

#### 方法 A：直接生成三视图

1. **构造提示词**

```python
from src.apps.comic_gen.llm import optimize_image_prompt

character = {
    "name": "女主角",
    "description": "23岁现代都市女性，长发及肩，棕色波浪卷，身材苗条，穿着粉色连衣裙，温柔气质"
}

# 使用 LLM 优化提示词
optimized_prompt = optimize_image_prompt(
    base_description=character["description"],
    target="character_turnaround",
    style="anime",
    platform="midjourney"  #  根据使用的平台调整
)

# 输出示例
"""
Character turnaround sheet, anime style, 23-year-old modern urban woman, 
shoulder-length wavy brown hair, slender figure, wearing pink dress, 
gentle temperament, 
three views: front view, side view, back view, 
white background, clean layout, consistent lighting, 
professional character design, high quality, 4K
"""
```

2. **调用文生图 API**

```python
from src.apps.comic_gen.assets import generate_character_turnaround

turnaround_image = generate_character_turnaround(
    prompt=optimized_prompt,
    model="midjourney",  # 或 "wanx-2.5", "qwen-image"
    aspect_ratio="16:9"
)

# 保存结果
turnaround_image.save("outputs/characters/female_lead_turnaround.png")
```

**提示词模板**（Midjourney）：

```
{character_description}, character turnaround sheet, 
three views: front view, side view, back view, 
same character in three angles, 
anime style, clean white background, consistent lighting, 
professional character design sheet, 
full body, highly detailed, 4K, --ar 16:9 --niji 6
```

**示例**：

| 原始描述 | 生成的三视图 | 提示词 |
|----------|--------------|--------|
| 20岁女性角色，黑色短发，蓝色校服 | ![示例图] | 保留人物所有特征，生成正视图、侧视图、背视图，放在同一张图片中 |

> [!IMPORTANT]
> **关键注意事项**：
> - 尽量生成全身照，否则鞋子等细节的一致性无法保持
> - 如果首次生成的三视图人物特征不够明显，可以要求在图片左侧增加"人物脸部特写"
> - 保存高分辨率原图，后续分镜生成需要引用

#### 方法 B：基于参考图编辑生成

如果已有角色参考图，可以通过图像编辑生成三视图：

```python
from src.apps.comic_gen.assets import edit_to_turnaround

# 加载参考图
ref_image = load_image("reference/character_ref.png")

# 编辑生成三视图
turnaround = edit_to_turnaround(
    reference_image=ref_image,
    edit_prompt="保持人物特征不变，生成正视图、侧视图和背视图在同一张图片中",
    model="wanx-i2i"
)
```

**实际案例**：

```
原图：一位穿着现代服装的男性角色半身照
编辑提示词：保持人物的特征和服装不变，生成正视图、侧视图和背视图。
          （尽量生成全身照，否则鞋子的一致性无法保持）

结果：生成包含三个视角的完整角色设计图
```

---

### 步骤 2.2：角色服装编辑

**目标**：在保持角色面部特征不变的情况下，更换服装

**操作步骤**：

1. **准备角色基础图**（通常使用三视图中的正视图）

2. **编辑服装**

```python
from src.apps.comic_gen.assets import edit_character_outfit

new_outfit_image = edit_character_outfit(
    character_image="outputs/characters/male_lead_turnaround.png",
    outfit_description="精致的中国古代龙袍，金色刺绣，暗红色底色",
    keep_features=True,  # 保持人物特征不变
    model="wanx-i2i"
)
```

**提示词示例**：

```
保持人物特征不变，把服装改成精致的龙袍
```

```
保持人物特征不变，把服装改成紧身的少林寺练功服
```

**高级用法：服装融合**

如果有具体的服装参考图：

```python
# 图1：角色图
# 图2：服装参考图

fusion_image = edit_with_reference(
    base_image="character.png",
    reference_image="outfit_reference.png",
    edit_prompt="保持图1风格不变，把图1男生的服装改成图2"
)
```

**Logo/图案添加示例**：

```
男生的卫衣胸前有一个小小的图2 logo，logo颜色需要融入动漫人物的整体风格
```

---

### 步骤 2.3：角色表情包生成

**目标**：生成同一角色的多种表情，用于不同情绪的分镜

**操作步骤**：

1. **生成表情矩阵**

```python
from src.apps.comic_gen.assets import generate_expression_pack

expressions = ["微笑", "大笑", "发呆", "悲伤", "惊吓", "愤怒"]

expression_grid = generate_expression_pack(
    character_image="outputs/characters/male_lead_front.png",
    expressions=expressions,
    grid_size=(2, 3),  # 2行3列
    model="wanx-i2i"
)
```

**提示词示例**：

```
生成这个男生的面部特写6宫格，保持面部特征不变，只改变表情，
生成微笑、大笑、发呆、悲伤、惊吓、愤怒6种不同的表情
```

**扩展表情集**：

```python
extended_expressions = [
    "尴尬", "惊喜", "假笑", "惊悚", "大哭", "狡猾"
]

expression_grid_2 = generate_expression_pack(
    character_image="outputs/characters/male_lead_front.png",
    expressions=extended_expressions,
    grid_size=(2, 3)
)
```

> [!TIP]
> 建议为每个主要角色生成至少 12-18 种表情，覆盖常见情绪：
> - 正面情绪：微笑、大笑、惊喜、兴奋、害羞
> - 负面情绪：悲伤、愤怒、恐惧、厌恶、失望
> - 中性情绪：发呆、思考、疑惑、冷漠、尴尬

---

### 步骤 2.4：场景图生成

**目标**：生成分镜所需的各类场景背景

**操作步骤**：

1. **文生图：从描述生成场景**

```python
from src.apps.comic_gen.assets import generate_scene

scene_prompt = optimize_image_prompt(
    base_description="老旧小区的楼道，左右两侧是两户家门，其中一个家门微微打开，楼道昏暗，暖黄色灯光",
    target="scene",
    style="anime",
    platform="midjourney"
)

scene_image = generate_scene(
    prompt=scene_prompt,
    model="midjourney",
    aspect_ratio="16:9"
)
```

**提示词示例**：

```
参考构图，生成老旧小区的楼道。楼道左右两侧分别是两户家门，
其中一个家门微微打开。动漫风格。
```

2. **场景编辑与细化**

```python
# 调整光线
edited_scene = edit_scene(
    scene_image=scene_image,
    edit_prompt="去除所有的阳光，只留下过道里的自然光。楼道昏暗灯光，暖黄色调。",
    model="wanx-i2i"
)

# 修改细节元素
final_scene = edit_scene(
    scene_image=edited_scene,
    edit_prompt="打开的门变成紧闭状态",
    model="wanx-i2i"
)
```

**提示词示例**：

```
去除所有的阳光，只留下过道里的自然光。楼道昏暗灯光，暖黄色调。
```

```
打开的门变成紧闭状态
```

---

### 步骤 2.5：道具与特效图生成

**目标**：生成剧情所需的道具和视觉特效元素

**操作步骤**：

1. **道具生成**

```python
from src.apps.comic_gen.assets import generate_prop

prop_prompt = """
透明玻璃杯，内装半杯金黄色蜂蜜水，
杯身有光线折射效果，放在白色背景上，
动漫风格，高清细节
"""

prop_image = generate_prop(
    prompt=prop_prompt,
    model="midjourney",
    background="transparent"  # 透明背景便于后续合成
)
```

2. **特效元素生成**

```python
# 生成结界光晕特效
effect_prompt = """
中国古代法阵，金色发光，圆形结界，
中心有神秘符文，周围环绕能量波纹，
透明背景，PNG格式，动漫风格
"""

effect_image = generate_effect(
    prompt=effect_prompt,
    model="midjourney"
)
```

**特效编辑示例**：

```
在结界光晕的中间打开一道裂缝，裂缝中间透出金光，金光里有一个模糊的中国古代人物人影
```

```
在结界的光圈中分出无数金色的小刀，小刀带有金色的剑气，仿佛要射出屏幕
```

```
近景，巨大的法阵在阴暗的天空中，占据画面的三分之二，镜头仰视法阵
```

```
法阵向地面射出一道道金光
```

---

## 分镜图生成

### 步骤 3.1：基础分镜生成（双图参考）

**目标**：通过图像参考和精确指令，生成角色和道具保持一致性的分镜图

**使用模型**：
- 提示词优化：Qwen3-VL-Plus (API) / Qwen3-30B-A3B
- 图生图：Midjourney / Wan2.5-i2i / Qwen-Image-edit

#### 3.1.1 人物 + 人物

**场景示例 1：室内互动场景**

```python
from src.apps.comic_gen.storyboard import generate_storyboard_shot

shot = generate_storyboard_shot(
    references=[
        "outputs/characters/male_lead_front.png",
        "outputs/characters/female_lead_front.png"
    ],
    scene_description="""
    全景，环境是室内客厅，窗外是夜景。
    前景的茶几上放着未喝完的蜂蜜水，
    男生背靠茶几后面的白色沙发，双手举过头顶，
    女生侧面跨坐在男生身上，俯身贴近男生的头。
    男生和女生目光对视。
    """,
    model="midjourney"
)
```

**提示词模板**：

```
全景，环境是{场景描述}。
图1的{角色A}做{动作A}，
图2的{角色B}做{动作B}，
两人{互动描述}。
动漫风格。
```

**场景示例 2：对战场景**

```
上下分屏效果，中间有倾斜的黑色间隙隔开，参考图中的两个角色相对而立，紧张对峙，
电影感灯光，高对比度。
上半部分：图2的男生伸出他的机械右臂向前，手掌迸发出明亮的青色闪电。
下半部分：图1的男生表情严肃，伸出他裸露的右臂向前，手掌迸发出强大的蓝色闪电。
背景：黑暗的工业风科幻走廊，带有金属墙壁和发光的蓝色线条。
```

**场景示例 3：动作对决**

```
动态动作场景，参考图中的两位角色在画面中央拳拳相碰，激烈对抗，
电影感灯光，高对比度，史诗般氛围。
左侧角色：图1的男生向前冲击，愤怒的表情，近景，周身环绕着翻腾的红色与橙色火焰
          及噼啪作响的红色闪电。
右侧角色：图2的男生向前冲击，愤怒的表情，近景，周身环绕着翻腾的蓝色水汽
          及闪耀的蓝色能量，并伴有电弧。
中心撞击点：双拳相击处爆发出耀眼的光芒，向四周辐射出多彩的能量波。
背景：黑暗的抽象虚空，带有细微的粒子效果。
```

#### 3.1.2 人物 + 场景

```python
shot = generate_storyboard_shot(
    references=[
        "outputs/scenes/barrier_scene.png",  # 结界场景
        "outputs/characters/old_master.png"  # 老头角色
    ],
    scene_description="""
    图2中的老头在图1的结界前紧闭双眼、皱着眉头，
    两手合于胸前，全神贯注的进行施法，
    老头的全身被黄色的剑气环绕。
    """,
    model="midjourney"
)
```

**提示词示例**：

```
男生坐在病房的床边，两手撑在身体两侧，低头看向地面，不知所措
```

```
图1的场景中弥漫着烟雾，街道的远处出现图2机器人的剪影，向镜头方向走来
```

#### 3.1.3 人物 + 道具

```
远景，图2的老头拿着图1中的棍子在练习，场景是瀑布前的小空地，动漫场景
```

```
近景，平视，侧面视角，图2的女生背上图1的包，走在动漫风格的日本东京街头
```

#### 3.1.4 人物 + 线稿

对于一些复杂的构图，可以先用线稿定义构图：

```
参考图2的构图，让图1中的人物站在高台上，高台是中国传统的亭子建筑，
高台下方是两排官员，环境是白天。其他细节请自行补充，让画面饱满。动漫风格。
```

```
参考图2的构图，通过一个男生背影的过肩视角，看到图1的女生全身，
场景在昏暗的教室内，动漫风格
```

#### 3.1.5 人物 + 特效

```
生成图1女生的手部特写，手掌向上参考图2发出粉色的花瓣，
花瓣向上升起散发出能量波动
```

```
让图2的机器人被图1的能量球包裹，机器人在能量球中打坐
```

```
参考图中的人物脸部和服装特征，生成动漫特效图片。
动漫风格，动态姿势，表情激烈，发光的橙色眼睛，凶狠的笑容，
胸前和手臂上有发光的红色闪电纹路，周身环绕着从身体迸发的熊熊烈焰，
站在夜晚的黑暗雨巷中，雨滴垂直落下，戏剧性灯光，高对比度，
电影构图，背景为模糊的建筑物，能量光环，强大气场，动作场景
```

---

### 步骤 3.2：基础分镜生成（三图参考）

**目标**：使用三张参考图（人物+人物+场景 或 人物+道具+场景）生成更复杂的分镜

> [!NOTE]
> 图片均为单次生成，未进行多次尝试。人物比例问题可通过二次编辑进行调整。

#### 3.2.1 人物 + 人物 + 场景

```python
shot = generate_storyboard_shot(
    references=[
        "outputs/characters/male_lead.png",     # 图1
        "outputs/characters/female_lead.png",   # 图2
        "outputs/scenes/hospital_room.png"      # 图3
    ],
    scene_description="图1的男生坐在图3的病床边，图2的女生站在图3的窗户边看着窗外",
    model="midjourney"
)
```

**提示词示例**：

```
图1和图2的男生在图3的场景中打斗
```

```
图一和图二的两人手拉手在图三的背景里跑步
```

#### 3.2.2 人物 + 动作 + 场景

使用动作参考图来定义角色的姿态：

```
图1的男生站在图3的场景中做出图2的动作
```

```
图1的女生在图3的场景中做出图2的动作
```

#### 3.2.3 人物 + 道具 + 场景

```
图1的女生背着图2的包，在图3的街道上向远处行走，留下拉长的影子
```

```
图1的男生出现在图3的楼道中，他探头看向门内，一手拿着图2的小熊玩偶
```

```
图1的机器人踩着图2的汽车在图3的马路中间
```

> [!TIP]
> 如果生成的人物比例不合适（如人物过大或过小），可以通过二次编辑调整：
> ```
> 保持画面元素和构图不变，将人物的比例缩小/放大到合理大小
> ```

#### 3.2.4 人物 + 特效 + 场景

```
图1的老头站在图3的祭台前，高举双手，天空中出现图2的结界光团
```

```
图1的女生站在图3的场景中，一只手掌向上参考图2发出粉色的花瓣，
花瓣向上升起散发出能量波动
```

```
在图3的场景中，空中出现图2的时空隧道，图1的机器人从时空隧道中从天而降
```

---

### 步骤 3.3：分镜效果优化

**目标**：通过精确指令编辑，精调分镜动作、视角、光线等细节

#### 3.3.1 人物表情和动作调整

```python
from src.apps.comic_gen.storyboard import refine_storyboard_shot

# 调整人物动作
refined_shot = refine_storyboard_shot(
    base_image="outputs/storyboard/shot_001.png",
    edit_prompt="图1中的男生单手指着女生",
    model="wanx-i2i"
)
```

**提示词示例**：

```
老头仰天大笑
```

```
保持机器人的特征不变，双手下垂，胸口射出蓝色激光，远处天空有闪电
```

#### 3.3.2 添加画面特效

```
保持图片背景和人物不变，为人物增加电子故障效果
```

```
保持图片背景和人物不变，把人物变成一团烟雾中的剪影
```

```
保持图片背景和人物不变，在人物的轮廓上添加一圈金光
```

```
保持图片背景和人物不变，把风格改成X光片风格
```

```
在背景中增加一道贯穿人物脑部的电流
```

#### 3.3.3 镜头调整

**镜头远近调整**：

```
把镜头拉远，展示病房的全貌
```

```
把镜头拉近，展示男生的面部特写，有一滴眼泪从眼角流出
```

```
特写镜头，聚焦在门口地面上空无一物，自然光线照射地面，形成明暗对比
```

**镜头角度调整**：

```
镜头切换到广角俯拍视角
```

```
镜头切换到仰拍视角，从地面拍向机器人，显得机器人很高大
```

> [!IMPORTANT]
> 镜头语言关键术语：
> - **景别**：远景、全景、中景、近景、特写、大特写
> - **角度**：平视、俯视、仰视、斜角、鸟瞰
> - **运动**：推镜头、拉镜头、摇镜头、跟镜头

#### 3.3.4 光线调整

```
改成夜晚的环境，电车站有微弱的灯光打在人物身上，背景的电车车窗里也透出灯光
```

```
把画面色调改成冷色调
```

```
把天气变成下雨天
```

```
把天气换成阴雨天
```

**光线术语**：
- 冷色调 / 暖色调
- 高对比度 / 柔和光线
- 逆光 / 顺光 / 侧光
- 戏剧性灯光 / 自然光

---

## 分镜视频生成

### 步骤 4.1：图生视频

**目标**：将静态分镜图转换为动态视频片段

**使用模型**：
- 提示词优化：Qwen3-VL-Plus (推荐) / Qwen3-30B-A3B
- 图生视频：Wan2.5-i2v / Wan2.2-i2v

**操作步骤**：

1. **使用 Qwen3-VL 分析分镜图并生成运动提示词**

```python
from src.apps.comic_gen.video import generate_motion_prompt
from src.apps.comic_gen.llm import optimize_video_prompt

# 加载分镜图
storyboard_image = "outputs/storyboard/shot_001.png"

# 使用视觉模型分析图片内容
image_analysis = analyze_image_for_motion(
    image_path=storyboard_image,
    model="qwen-vl-plus"
)

# 构造基础运动描述
base_motion = """
镜头缓慢推进，女生的头发随风轻轻飘动，
男生的眼神从地面移向女生，
窗外的夜景灯光闪烁
"""

# 优化为适合图生视频的提示词
optimized_motion_prompt = optimize_video_prompt(
    base_description=base_motion,
    image_analysis=image_analysis,
    model="qwen-vl-plus",
    platform="wanx"  # 根据使用的平台调整
)
```

**Qwen3-VL 提示词优化系统提示词**：

```
你是专业的视频运动提示词优化专家。

任务：基于给定的图片和初步运动描述，生成优化后的图生视频提示词。

要求：
1. 分析图片中的关键元素（人物、物体、环境）
2. 在保持原始意图的基础上，优化和补充运动描述
3. 确保运动合理、自然，符合物理规律
4. 运动幅度适中，避免过于剧烈的变化
5. 突出重点运动元素，次要元素可以有微妙变化
6. 使用专业的运动术语（缓慢、快速、平滑、突然等）
7. 考虑镜头运动（推、拉、摇、移等）

输出格式：
直接输出优化后的提示词，不需要额外说明。

示例：
输入图片：室内场景，男女对视
初步描述：两人看着对方
优化输出：镜头缓慢推进，女生的长发随微风轻轻飘动，男生的目光从茫然逐渐变得坚定，
         两人眼神交汇，窗外的夜景灯光柔和闪烁，营造温馨氛围
```

2. **调用图生视频 API**

```python
from src.apps.comic_gen.video import generate_video_from_frame

video_clip = generate_video_from_frame(
    frame_image=storyboard_image,
    motion_prompt=optimized_motion_prompt,
    model="wanx-i2v-2.5",  # 或 "wanx-i2v-2.2"
    duration=4,  # 秒
    fps=24
)

video_clip.save("outputs/videos/shot_001.mp4")
```

**运动提示词示例**：

| 场景类型 | 运动提示词示例 |
|----------|----------------|
| 人物对话 | 镜头缓慢推进，女生微微侧头，男生眼神坚定，嘴唇轻微动作表示说话 |
| 动作场景 | 镜头快速旋转，两人拳头快速相撞，冲击波向四周扩散，碎片飞溅 |
| 环境揭示 | 镜头从上至下缓慢下移，逐渐揭示场景全貌，人物静止不动 |
| 情绪特写 | 镜头聚焦人物面部，一滴眼泪缓慢从眼角滑落，脸部肌肉微妙变化 |

> [!WARNING]
> **图生视频常见问题**：
> - **运动过大**：会导致画面扭曲或人物变形，应使用"缓慢"、"微妙"等词
> - **元素过多**：同时描述过多运动会导致混乱，应聚焦 1-2 个主要运动
> - **违反物理规律**：如头发向上飘但无风，会导致不自然

---

### 步骤 4.2：视频片段管理

**目标**：组织和管理生成的视频片段，为后续合成做准备

```python
from src.apps.comic_gen.pipeline import VideoSequence

# 创建视频序列
sequence = VideoSequence(project_name="episode_001")

# 添加视频片段
sequence.add_clip(
    clip_id="S001_01",
    video_path="outputs/videos/shot_001.mp4",
    duration=4.0,
    scene_id="S001"
)

sequence.add_clip(
    clip_id="S001_02",
    video_path="outputs/videos/shot_002.mp4",
    duration=3.5,
    scene_id="S001"
)

# 保存序列信息
sequence.save("outputs/projects/episode_001/sequence.json")
```

---

## 音频制作

### 步骤 5.1：角色配音生成

**目标**：为每个角色生成符合其性格特点的配音

**使用模型**：
- 推荐：Qwen3-TTS (API) / CosyVoice3 (API)
- 可选：CosyVoice2 (独立部署) / Index TTS (独立部署)

**操作步骤**：

1. **准备配音文本**

从分镜脚本中提取对话：

```python
from src.apps.comic_gen.audio import extract_dialogues

dialogues = extract_dialogues("outputs/projects/episode_001/sequence.json")

# 输出示例
[
    {
        "clip_id": "S001_01",
        "character": "女主角",
        "text": "你真的决定了吗？",
        "emotion": "担忧",
        "start_time": 1.5,
        "duration": 2.0
    },
    {
        "clip_id": "S001_01",
        "character": "男主角",
        "text": "我已经想清楚了。",
        "emotion": "坚定",
        "start_time": 3.8,
        "duration": 1.5
    }
]
```

2. **配置角色声音**

```python
from src.apps.comic_gen.audio import configure_character_voice

# 为女主角配置声音
female_voice = configure_character_voice(
    character_name="女主角",
    gender="female",
    age_range="young",  # young / middle / old
    tone="gentle",      # gentle / energetic / cold / playful
    pitch=1.1,          # 音调：0.8-1.2，1.0为标准
    speed=1.0,          # 语速：0.5-2.0，1.0为标准
    model="cosyvoice3"
)

# 为男主角配置声音
male_voice = configure_character_voice(
    character_name="男主角",
    gender="male",
    age_range="young",
    tone="calm",
    pitch=0.9,
    speed=1.0,
    model="cosyvoice3"
)
```

3. **生成配音**

```python
from src.apps.comic_gen.audio import generate_voice_acting

for dialogue in dialogues:
    if dialogue["character"] == "女主角":
        voice_config = female_voice
    else:
        voice_config = male_voice
    
    # 生成配音
    audio_file = generate_voice_acting(
        text=dialogue["text"],
        voice_config=voice_config,
        emotion=dialogue["emotion"],  # 情绪控制
        output_path=f"outputs/audio/voice/{dialogue['clip_id']}_{dialogue['character']}.wav"
    )
```

**情绪标签参考**：
- 正面：开心、兴奋、温柔、自信、坚定
- 负面：悲伤、愤怒、恐惧、失望、绝望
- 中性：平静、思考、疑惑、冷漠

---

### 步骤 5.2：环境音效生成

**目标**：为场景添加环境音和音效

**使用模型**：
- 推荐：MMAudio (独立部署)
- 可选：ThinkSound

**操作步骤**：

1. **环境背景音**

```python
from src.apps.comic_gen.audio import generate_ambient_sound

# 为室内客厅场景生成环境音
ambient = generate_ambient_sound(
    scene_description="室内客厅，夜晚，窗外城市车流声，室内钟表滴答声",
    duration=10.0,
    model="mmaudio",
    volume=0.3  # 背景音音量较低
)

ambient.save("outputs/audio/ambient/living_room_night.wav")
```

2. **动作音效**

```python
from src.apps.comic_gen.audio import generate_sound_effect

# 生成拳击音效
punch_sfx = generate_sound_effect(
    effect_type="punch",
    intensity="strong",
    duration=0.5,
    model="mmaudio"
)

# 生成脚步声
footsteps_sfx = generate_sound_effect(
    effect_type="footsteps",
    surface="wooden_floor",
    pace="slow",
    duration=3.0,
    model="mmaudio"
)
```

**常用音效类型**：
- 动作：拳击、脚步、关门、玻璃碎裂
- 自然：风声、雨声、雷声、水流
- 特效：能量爆发、闪电、传送、爆炸
- 环境：城市街道、办公室、餐厅、森林

---

### 步骤 5.3：音频合成与同步

**目标**：将配音、音效、背景音乐混合，并与视频同步

```python
from src.apps.comic_gen.audio import mix_audio_tracks

# 为每个视频片段混合音频
audio_mix = mix_audio_tracks(
    video_clip="outputs/videos/shot_001.mp4",
    voice_tracks=[
        {"file": "outputs/audio/voice/S001_01_女主角.wav", "start_time": 1.5},
        {"file": "outputs/audio/voice/S001_01_男主角.wav", "start_time": 3.8}
    ],
    sfx_tracks=[
        {"file": "outputs/audio/sfx/door_open.wav", "start_time": 0.5}
    ],
    ambient_track={
        "file": "outputs/audio/ambient/living_room_night.wav",
        "volume": 0.3,
        "fade_in": 0.5,
        "fade_out": 0.5
    },
    bgm_track={
        "file": "assets/music/emotional_bgm.mp3",
        "volume": 0.2,
        "loop": False
    }
)

# 输出混合音频
audio_mix.save("outputs/audio/mixed/shot_001_audio.wav")
```

**音频混合参考音量**：
- 对话配音：0.8 - 1.0
- 音效：0.5 - 0.8（根据重要性调整）
- 环境音：0.2 - 0.4
- 背景音乐：0.15 - 0.3

---

## 后期优化与导出

### 步骤 6.1：视频合成

**目标**：将所有视频片段、音频按时间轴合成最终视频

```python
from src.apps.comic_gen.export import compose_final_video

# 创建时间轴
timeline = create_timeline([
    {
        "clip_id": "S001_01",
        "video": "outputs/videos/shot_001.mp4",
        "audio": "outputs/audio/mixed/shot_001_audio.wav",
        "duration": 4.0,
        "transition": "fade"  # 转场效果
    },
    {
        "clip_id": "S001_02",
        "video": "outputs/videos/shot_002.mp4",
        "audio": "outputs/audio/mixed/shot_002_audio.wav",
        "duration": 3.5,
        "transition": "cut"
    }
])

# 合成最终视频
final_video = compose_final_video(
    timeline=timeline,
    output_path="outputs/final/episode_001.mp4",
    resolution="1920x1080",
    fps=24,
    codec="h264",
    bitrate="8M"
)
```

**转场效果类型**：
- `cut`：硬切（无过渡）
- `fade`：淡入淡出
- `dissolve`：溶解
- `wipe`：擦除
- `slide`：滑动

---

### 步骤 6.2：添加字幕

**目标**：为视频添加对话字幕

```python
from src.apps.comic_gen.export import add_subtitles

# 从对话数据生成字幕文件
subtitles = generate_subtitles(
    dialogues=dialogues,
    format="srt"  # 或 "ass", "vtt"
)

subtitles.save("outputs/final/episode_001.srt")

# 将字幕嵌入视频
final_with_subtitles = add_subtitles(
    video_path="outputs/final/episode_001.mp4",
    subtitle_path="outputs/final/episode_001.srt",
    font="Sans-serif",
    font_size=24,
    color="white",
    outline_color="black",
    outline_width=2,
    position="bottom"
)

final_with_subtitles.save("outputs/final/episode_001_subtitled.mp4")
```

---

### 步骤 6.3：质量检查与导出

**目标**：检查最终成片质量，导出不同格式

```python
from src.apps.comic_gen.export import quality_check, export_video

# 质量检查
qc_report = quality_check(
    video_path="outputs/final/episode_001_subtitled.mp4",
    checks=[
        "video_integrity",    # 视频完整性
        "audio_sync",         # 音画同步
        "subtitle_timing",    # 字幕时间
        "resolution",         # 分辨率
        "bitrate"             # 码率
    ]
)

print(qc_report)

# 导出多种格式
export_video(
    source="outputs/final/episode_001_subtitled.mp4",
    formats=[
        {"format": "mp4", "resolution": "1920x1080", "bitrate": "8M"},
        {"format": "mp4", "resolution": "1280x720", "bitrate": "4M"},
        {"format": "webm", "resolution": "1920x1080", "bitrate": "6M"}
    ],
    output_dir="outputs/final/exports/"
)
```

---

## 技术栈与模型配置

### 完整技术栈一览

| 制作流程 | 配套能力 | 配套模型 | 配套工具 |
|----------|----------|----------|----------|
| **分镜脚本拆分** | 提示词工程实现结构化数据提取 | Qwen3-Plus (API, 推荐)<br/>Qwen3-30B-A3B (可独立部署) | - |
| **角色/道具/场景提取** | 同上 | 同上 | - |
| **角色图/场景图/道具图** | 提示词优化 + 文生图 | **提示词优化**：Qwen3-Plus / Qwen3-30B-A3B<br/>**文生图**：Midjourney (API) / Wan2.5-t2i / Qwen-Image | ComfyUI / Diffusers Pipeline |
| **分镜图生成** | 提示词优化 + 图生图 | **提示词优化**：Qwen3-VL-Plus / Qwen3-30B-A3B<br/>**图生图**：Midjourney / Wan2.5-i2i / Qwen-Image-edit | ComfyUI / Diffusers Pipeline |
| **分镜视频生成** | 提示词优化 + 图生视频 | **提示词优化**：Qwen3-VL-Plus / Qwen3-30B-A3B<br/>**图生视频**：Wan2.5-i2v / Wan2.2-i2v | - |
| **角色配音** | AI 声音制作/克隆 | Qwen3-TTS (API, 推荐)<br/>CosyVoice3 (API, 推荐)<br/>CosyVoice2 / Index TTS (独立部署) | [Index TTS](https://github.com/index-tts/index-tts) |
| **环境音/音效** | 音效制作 | ThinkSound<br/>MMAudio (独立部署, 推荐) | [MMAudio](https://github.com/hkchengrex/MMAudio) |

---

### 模型推荐配置

#### 配置 A：全 API（最简单）

适合快速启动，无需本地部署

```yaml
llm:
  text_model: qwen-plus
  vision_model: qwen-vl-plus
  
text_to_image:
  model: midjourney  # 或 wanx-t2i
  
image_to_image:
  model: midjourney  # 或 wanx-i2i
  
image_to_video:
  model: wanx-i2v-2.5
  
tts:
  model: cosyvoice3
```

#### 配置 B：混合部署（平衡性能与成本）

```yaml
llm:
  text_model: qwen-30b-a3b  # 本地部署
  vision_model: qwen-vl-plus  # API
  
text_to_image:
  model: qwen-image  # 本地部署
  
image_to_image:
  model: wanx-i2i  # API
  
image_to_video:
  model: wanx-i2v-2.2  # 本地部署
  
tts:
  model: cosyvoice2  # 本地部署
  
sound_effects:
  model: mmaudio  # 本地部署
```

#### 配置 C：全本地部署（最高隐私）

```yaml
llm:
  text_model: qwen-30b-a3b
  vision_model: qwen-vl-7b  # 或更大模型
  
generation:
  text_to_image: qwen-image
  image_to_image: qwen-image-edit
  image_to_video: wanx-i2v-2.2
  
audio:
  tts: index-tts
  sound_effects: mmaudio
  
infrastructure:
  comfyui: true  # 使用 ComfyUI 工作流
```

---

### API 配置示例

创建 `config/models.yaml`：

```yaml
# Qwen API Configuration
qwen:
  api_key: "your-api-key"
  base_url: "https://dashscope.aliyuncs.com/api/v1"
  models:
    text: "qwen-plus"
    vision: "qwen-vl-plus"
    image_gen: "wanx-v1"
    
# Midjourney API Configuration (if using)
midjourney:
  api_key: "your-mj-api-key"
  callback_url: "https://your-domain.com/callback"
  
# Wanx API Configuration
wanx:
  api_key: "your-wanx-api-key"
  endpoints:
    t2i: "wanx-2.5-t2i"
    i2i: "wanx-2.5-i2i"
    i2v: "wanx-2.5-i2v"
    
# CosyVoice API Configuration
cosyvoice:
  api_key: "your-cosyvoice-api-key"
  model: "cosyvoice3"
```

---

## 最佳实践与常见问题

### 提示词工程最佳实践

#### 1. 文生图提示词结构

```
[主体描述] + [风格] + [质量词] + [技术参数]

示例：
23-year-old urban woman, shoulder-length brown wavy hair, pink dress, gentle expression,
anime style, highly detailed, professional illustration,
soft lighting, clean background, 4K, --ar 16:9 --niji 6
```

**关键要素**：
- 主体：年龄、性别、发型、服装、表情
- 风格：anime / realistic / cartoon / oil painting
- 质量：highly detailed / professional / high quality / 4K
- 灯光：soft lighting / dramatic lighting / natural light
- 构图：close-up / full body / portrait

#### 2. 图生图提示词结构

```
[保持要求] + [编辑指令] + [细节补充]

示例：
保持人物特征不变，把服装改成精致的中国古代龙袍，金色刺绣，暗红色底色
```

**关键要素**：
- 明确指定要保持的元素
- 清晰描述要修改的部分
- 补充必要的细节描述

#### 3. 图生视频提示词结构

```
[镜头运动] + [主体运动] + [环境变化] + [细节动态]

示例：
镜头缓慢推进，女生的长发随风轻轻飘动，男生的目光从茫然逐渐变得坚定，
窗外的夜景灯光柔和闪烁
```

**关键要素**：
- 镜头：推/拉/摇/移/静止
- 主体：动作、表情、姿态变化
- 环境：光线、天气、氛围
- 细节：头发、衣物、粒子效果

---

### 常见问题与解决方案

#### Q1：角色一致性问题

**问题**：不同分镜中同一角色外观不一致

**解决方案**：
1. 先生成高质量的角色三视图作为参考
2. 每次生成分镜时都引用角色三视图
3. 使用 "保持图X的人物特征" 等明确指令
4. 如果平台支持，使用 ControlNet 或 IPAdapter 确保一致性

#### Q2：图生视频运动不自然

**问题**：生成的视频出现抖动、变形、不合理运动

**解决方案**：
1. 减少运动幅度，使用 "缓慢"、"微妙" 等词
2. 避免同时描述过多运动元素
3. 使用 Qwen3-VL 优化运动提示词
4. 选择运动较少的关键帧作为起始帧

#### Q3：配音与口型不同步

**问题**：角色配音与画面中的嘴部动作不匹配

**解决方案**：
1. 在图生视频时避免描述嘴部运动
2. 使用后期工具进行口型同步（如 Wav2Lip）
3. 优先选择背影、侧面等不显示嘴部的镜头进行对话
4. 对于正面对话，可以用特写切换减少不同步感

#### Q4：长视频生成效率低

**问题**：完整剧集生成时间过长

**解决方案**：
1. **并行处理**：使用多线程同时生成多个片段
2. **分段制作**：按场景分段，逐步完成
3. **复用素材**：相同场景/角色的镜头复用素材
4. **本地部署**：高频使用的模型部署到本地，减少 API 延迟

```python
# 并行生成示例
from concurrent.futures import ThreadPoolExecutor

def generate_shot(shot_config):
    # 生成单个镜头的逻辑
    pass

with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(generate_shot, shot) for shot in shot_list]
    results = [f.result() for f in futures]
```

#### Q5：成本控制

**问题**：API 调用成本过高

**解决方案**：
1. **关键步骤使用 API，辅助步骤本地部署**
2. **批量生成**：一次性生成多个变体，选择最佳
3. **缓存机制**：对相同输入缓存结果
4. **提示词优化**：在调用昂贵 API 前，先用本地模型优化提示词

---

### 工作流自动化脚本

完整的端到端自动化示例：

```python
from src.apps.comic_gen.pipeline import ComicProductionPipeline

# 初始化流程
pipeline = ComicProductionPipeline(
    project_name="my_comic_episode_001",
    config_path="config/models.yaml"
)

# 步骤 1：剧本分析
pipeline.analyze_script(
    script_path="scripts/episode_001.txt",
    output_dir="outputs/analysis/"
)

# 步骤 2：生成素材
pipeline.generate_assets(
    characters=["male_lead", "female_lead"],
    scenes=["living_room", "street"],
    props=["honey_water", "backpack"]
)

# 步骤 3：生成分镜
pipeline.generate_storyboard(
    parallel_workers=4  # 并行生成 4 个分镜
)

# 步骤 4：生成视频
pipeline.generate_videos(
    use_qwen_vl_optimization=True
)

# 步骤 5：音频制作
pipeline.generate_audio(
    voice_acting=True,
    sound_effects=True,
    bgm_path="assets/music/bgm.mp3"
)

# 步骤 6：合成与导出
pipeline.compose_and_export(
    output_path="outputs/final/episode_001.mp4",
    resolution="1920x1080",
    add_subtitles=True
)

print("制作完成！")
```

---

## 附录

### A. 目录结构建议

```
project_root/
├── config/
│   ├── models.yaml           # 模型配置
│   └── production.yaml       # 制作流程配置
├── scripts/
│   └── episode_001.txt       # 原始剧本
├── outputs/
│   ├── analysis/
│   │   ├── structured_script.json
│   │   ├── characters.json
│   │   ├── scenes.json
│   │   └── props.json
│   ├── assets/
│   │   ├── characters/
│   │   │   ├── male_lead_turnaround.png
│   │   │   ├── male_lead_expressions.png
│   │   │   └── female_lead_turnaround.png
│   │   ├── scenes/
│   │   │   ├── living_room.png
│   │   │   └── street.png
│   │   └── props/
│   │       └── honey_water.png
│   ├── storyboard/
│   │   ├── shot_001.png
│   │   ├── shot_002.png
│   │   └── ...
│   ├── videos/
│   │   ├── shot_001.mp4
│   │   ├── shot_002.mp4
│   │   └── ...
│   ├── audio/
│   │   ├── voice/
│   │   ├── sfx/
│   │   ├── ambient/
│   │   └── mixed/
│   └── final/
│       ├── episode_001.mp4
│       ├── episode_001.srt
│       └── exports/
└── src/
    └── apps/
        └── comic_gen/
            ├── pipeline.py
            ├── llm.py
            ├── assets.py
            ├── storyboard.py
            ├── video.py
            ├── audio.py
            └── export.py
```

### B. 常用命令速查

```bash
# 安装依赖
pip install -r requirements.txt

# 测试 pipeline
python src/apps/comic_gen/test_pipeline.py

# 运行完整流程
python scripts/run_production.py --script scripts/episode_001.txt

# 仅生成分镜
python scripts/run_production.py --stage storyboard --input outputs/assets/

# 仅生成视频
python scripts/run_production.py --stage video --input outputs/storyboard/

# 导出最终成片
python scripts/run_production.py --stage export --input outputs/videos/
```

### C. 快捷链接

- [Qwen API 文档](https://help.aliyun.com/zh/dashscope/)
- [Wanx API 文档](https://help.aliyun.com/zh/model-studio/developer-reference/wanx-api)
- [MMAudio GitHub](https://github.com/hkchengrex/MMAudio)
- [Index TTS GitHub](https://github.com/index-tts/index-tts)
- [ComfyUI 官方文档](https://github.com/comfyanonymous/ComfyUI)

---

**文档版本**：v1.0  
**最后更新**：2025-11-27  
**维护者**：comic_gen 项目团队

> [!NOTE]
> 本文档会随着项目发展持续更新。如有问题或建议请提交 Issue。
